﻿#include "pch.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdio.h>
#include "Preparations.h"
#include "Dynamic.h"
#include "Annealing.h"
#include "czas.h"
#include "Genetic.h"

int main()
{
	srand(time(NULL));
	int path=INT_MAX;
	int length;
	int option;
	czas czas;
	std::string fileName = "data18.txt";
	Genetic genetic;
	genetic.setFileName(fileName);
	genetic.loadFromFile();
	std::vector<int> permutation(genetic.getVectorLength());
	length = genetic.getVectorLength();
	for (int i = 0; i < length; i++)
	{
		permutation[i] = i;
	}
	/*for (int i = 0; i < annealing.getVectorLength(); i++)
	{
		permutation[i] = i;
	}
	bestPermutation = annealing.findRoute(permutation);
	for (int i = 0; i < annealing.getVectorLength(); i++)
	{
		std::cout << bestPermutation[i] << "\t";
	}
	std::cout << annealing.countLength(bestPermutation) << std::endl;
	*/
	/*
	std::fstream plik;
	plik.open("wyniki.txt", std::ios::out);
	float srednia = 0;
	float sredniBlad = 0;
	float tempMax = 10000;
	float tempMin = 0.99;
	float rate = 0.000001;
		fileName = "data26.txt";
		for (int j = 2; j < 27; j++)
		{
			path = INT_MAX;
			annealing.setFileName(fileName);
			annealing.loadFromFile();
			std::vector<int> permutation(annealing.getVectorLength());
			std::vector<int> bestPermutation(annealing.getVectorLength());
			length = annealing.getVectorLength();
			for (int i = 0; i < annealing.getVectorLength(); i++)
			{
				permutation[i] = i;
			}
			czas.czasStart();
			bestPermutation = annealing.findRoute(permutation,tempMax,tempMin,rate);
			czas.czasStop();
			srednia *= (j - 1);
			srednia += czas.czasWykonania();
			srednia /= j;
			sredniBlad *= (j - 1);
			sredniBlad += ((float)annealing.countLength(bestPermutation) / 937) - 1;
			sredniBlad /= j;
		}
		plik<<sredniBlad<<"		" << srednia << "		" << tempMax << "		" << tempMin << "		" << rate << "  " << fileName << std::endl;
		srednia = 0;
		fileName = "data42.txt";
		for (int j = 2; j < 27; j++)
		{
			path = INT_MAX;
			annealing.setFileName(fileName);
			annealing.loadFromFile();
			std::vector<int> permutation(annealing.getVectorLength());
			std::vector<int> bestPermutation(annealing.getVectorLength());
			length = annealing.getVectorLength();
			for (int i = 0; i < annealing.getVectorLength(); i++)
			{
				permutation[i] = i;
			}
			czas.czasStart();
			bestPermutation = annealing.findRoute(permutation, tempMax, tempMin, rate);
			czas.czasStop();
			srednia *= (j - 1);
			srednia += czas.czasWykonania();
			srednia /= j;
			sredniBlad *= (j - 1);
			sredniBlad += ((float)annealing.countLength(bestPermutation) / 699) - 1;
			sredniBlad /= j;
		}
		plik << sredniBlad << "		" << srednia << "		" << tempMax << "		" << tempMin << "		" << rate << "  " << fileName << std::endl;
		srednia = 0;
	*/
	/*
	tempMax = 10000;
	tempMin = 0.99;
	rate = 0.001;
	for (int i = 10; i < 19; i++)
	{
		fileName = "data" + std::to_string(i) + ".txt";
		for (int j = 2; j < 102; j++)
		{
			path = INT_MAX;
			annealing.setFileName(fileName);
			annealing.loadFromFile();
			std::vector<int> permutation(annealing.getVectorLength());
			std::vector<int> bestPermutation(annealing.getVectorLength());
			length = annealing.getVectorLength();
			for (int i = 0; i < annealing.getVectorLength(); i++)
			{
				permutation[i] = i;
			}
			czas.czasStart();
			bestPermutation = annealing.findRoute(permutation, tempMax, tempMin, rate);
			czas.czasStop();
			srednia *= (j - 1);
			srednia += czas.czasWykonania();
			srednia /= j;
			sredniBlad *= (j - 1);
			switch (i)
			{
			case 10:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 212) - 1;
				break;
			case 11:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 202) - 1;
				break;
			case 12:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 264) - 1;
				break;
			case 13:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 269) - 1;
				break;
			case 14:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 125) - 1;
				break;
			case 15:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 291) - 1;
				break;
			case 16:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 156) - 1;
				break;
			case 17:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 2085) - 1;
				break;
			case 18:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 187) - 1;
				break;
			}

			sredniBlad /= j;
		}
		plik << sredniBlad << "		" << srednia << "		" << tempMax << "		" << tempMin << "		" << rate << "  " << fileName << std::endl;
		srednia = 0;
	}
	tempMax = 25000;
	tempMin = 0.99;
	rate = 0.001;
	for (int i = 10; i < 19; i++)
	{
		fileName = "data" + std::to_string(i) + ".txt";
		for (int j = 2; j < 102; j++)
		{
			path = INT_MAX;
			annealing.setFileName(fileName);
			annealing.loadFromFile();
			std::vector<int> permutation(annealing.getVectorLength());
			std::vector<int> bestPermutation(annealing.getVectorLength());
			length = annealing.getVectorLength();
			for (int i = 0; i < annealing.getVectorLength(); i++)
			{
				permutation[i] = i;
			}
			czas.czasStart();
			bestPermutation = annealing.findRoute(permutation, tempMax, tempMin, rate);
			czas.czasStop();
			srednia *= (j - 1);
			srednia += czas.czasWykonania();
			srednia /= j;
			sredniBlad *= (j - 1);
			switch (i)
			{
			case 10:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 212) - 1;
				break;
			case 11:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 202) - 1;
				break;
			case 12:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 264) - 1;
				break;
			case 13:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 269) - 1;
				break;
			case 14:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 125) - 1;
				break;
			case 15:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 291) - 1;
				break;
			case 16:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 156) - 1;
				break;
			case 17:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 2085) - 1;
				break;
			case 18:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 187) - 1;
				break;
			}

			sredniBlad /= j;
		}
		plik << sredniBlad << "		" << srednia << "		" << tempMax << "		" << tempMin << "		" << rate << "  " << fileName << std::endl;
		srednia = 0;
	}
	tempMax = 50000;
	tempMin = 0.99;
	rate = 0.001;
	for (int i = 10; i < 19; i++)
	{
		fileName = "data" + std::to_string(i) + ".txt";
		for (int j = 2; j < 102; j++)
		{
			path = INT_MAX;
			annealing.setFileName(fileName);
			annealing.loadFromFile();
			std::vector<int> permutation(annealing.getVectorLength());
			std::vector<int> bestPermutation(annealing.getVectorLength());
			length = annealing.getVectorLength();
			for (int i = 0; i < annealing.getVectorLength(); i++)
			{
				permutation[i] = i;
			}
			czas.czasStart();
			bestPermutation = annealing.findRoute(permutation, tempMax, tempMin, rate);
			czas.czasStop();
			srednia *= (j - 1);
			srednia += czas.czasWykonania();
			srednia /= j;
			sredniBlad *= (j - 1);
			switch (i)
			{
			case 10:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 212) - 1;
				break;
			case 11:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 202) - 1;
				break;
			case 12:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 264) - 1;
				break;
			case 13:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 269) - 1;
				break;
			case 14:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 125) - 1;
				break;
			case 15:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 291) - 1;
				break;
			case 16:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 156) - 1;
				break;
			case 17:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 2085) - 1;
				break;
			case 18:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 187) - 1;
				break;
			}

			sredniBlad /= j;
		}
		plik << sredniBlad << "		" << srednia << "		" << tempMax << "		" << tempMin << "		" << rate << "  " << fileName << std::endl;
		srednia = 0;
	}
	tempMax = 100000;
	tempMin = 0.99;
	rate = 0.001;
	for (int i = 10; i < 19; i++)
	{
		fileName = "data" + std::to_string(i) + ".txt";
		for (int j = 2; j < 102; j++)
		{
			path = INT_MAX;
			annealing.setFileName(fileName);
			annealing.loadFromFile();
			std::vector<int> permutation(annealing.getVectorLength());
			std::vector<int> bestPermutation(annealing.getVectorLength());
			length = annealing.getVectorLength();
			for (int i = 0; i < annealing.getVectorLength(); i++)
			{
				permutation[i] = i;
			}
			czas.czasStart();
			bestPermutation = annealing.findRoute(permutation, tempMax, tempMin, rate);
			czas.czasStop();
			srednia *= (j - 1);
			srednia += czas.czasWykonania();
			srednia /= j;
			sredniBlad *= (j - 1);
			switch (i)
			{
			case 10:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 212) - 1;
				break;
			case 11:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 202) - 1;
				break;
			case 12:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 264) - 1;
				break;
			case 13:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 269) - 1;
				break;
			case 14:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 125) - 1;
				break;
			case 15:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 291) - 1;
				break;
			case 16:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 156) - 1;
				break;
			case 17:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 2085) - 1;
				break;
			case 18:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 187) - 1;
				break;
			}

			sredniBlad /= j;
		}
		plik << sredniBlad << "		" << srednia << "		" << tempMax << "		" << tempMin << "		" << rate << "  " << fileName << std::endl;
		srednia = 0;
	}
	tempMax = 5000;
	tempMin = 0.99;
	rate = 0.0001;
	for (int i = 10; i < 19; i++)
	{
		fileName = "data" + std::to_string(i) + ".txt";
		for (int j = 2; j < 102; j++)
		{
			path = INT_MAX;
			annealing.setFileName(fileName);
			annealing.loadFromFile();
			std::vector<int> permutation(annealing.getVectorLength());
			std::vector<int> bestPermutation(annealing.getVectorLength());
			length = annealing.getVectorLength();
			for (int i = 0; i < annealing.getVectorLength(); i++)
			{
				permutation[i] = i;
			}
			czas.czasStart();
			bestPermutation = annealing.findRoute(permutation, tempMax, tempMin, rate);
			czas.czasStop();
			srednia *= (j - 1);
			srednia += czas.czasWykonania();
			srednia /= j;
			sredniBlad *= (j - 1);
			switch (i)
			{
			case 10:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 212) - 1;
				break;
			case 11:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 202) - 1;
				break;
			case 12:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 264) - 1;
				break;
			case 13:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 269) - 1;
				break;
			case 14:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 125) - 1;
				break;
			case 15:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 291) - 1;
				break;
			case 16:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 156) - 1;
				break;
			case 17:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 2085) - 1;
				break;
			case 18:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 187) - 1;
				break;
			}

			sredniBlad /= j;
		}
		plik << sredniBlad << "		" << srednia << "		" << tempMax << "		" << tempMin << "		" << rate << "  " << fileName << std::endl;
		srednia = 0;
	}
	tempMax = 5000;
	tempMin = 0.99;
	rate = 0.00005;
	for (int i = 10; i < 19; i++)
	{
		fileName = "data" + std::to_string(i) + ".txt";
		for (int j = 2; j < 102; j++)
		{
			path = INT_MAX;
			annealing.setFileName(fileName);
			annealing.loadFromFile();
			std::vector<int> permutation(annealing.getVectorLength());
			std::vector<int> bestPermutation(annealing.getVectorLength());
			length = annealing.getVectorLength();
			for (int i = 0; i < annealing.getVectorLength(); i++)
			{
				permutation[i] = i;
			}
			czas.czasStart();
			bestPermutation = annealing.findRoute(permutation, tempMax, tempMin, rate);
			czas.czasStop();
			srednia *= (j - 1);
			srednia += czas.czasWykonania();
			srednia /= j;
			sredniBlad *= (j - 1);
			switch (i)
			{
			case 10:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 212) - 1;
				break;
			case 11:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 202) - 1;
				break;
			case 12:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 264) - 1;
				break;
			case 13:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 269) - 1;
				break;
			case 14:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 125) - 1;
				break;
			case 15:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 291) - 1;
				break;
			case 16:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 156) - 1;
				break;
			case 17:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 2085) - 1;
				break;
			case 18:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 187) - 1;
				break;
			}

			sredniBlad /= j;
		}
		plik << sredniBlad << "		" << srednia << "		" << tempMax << "		" << tempMin << "		" << rate << "  " << fileName << std::endl;
		srednia = 0;
	}
	tempMax = 5000;
	tempMin = 0.99;
	rate = 0.00001;
	for (int i = 10; i < 19; i++)
	{
		fileName = "data" + std::to_string(i) + ".txt";
		for (int j = 2; j < 102; j++)
		{
			path = INT_MAX;
			annealing.setFileName(fileName);
			annealing.loadFromFile();
			std::vector<int> permutation(annealing.getVectorLength());
			std::vector<int> bestPermutation(annealing.getVectorLength());
			length = annealing.getVectorLength();
			for (int i = 0; i < annealing.getVectorLength(); i++)
			{
				permutation[i] = i;
			}
			czas.czasStart();
			bestPermutation = annealing.findRoute(permutation, tempMax, tempMin, rate);
			czas.czasStop();
			srednia *= (j - 1);
			srednia += czas.czasWykonania();
			srednia /= j;
			sredniBlad *= (j - 1);
			switch (i)
			{
			case 10:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 212) - 1;
				break;
			case 11:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 202) - 1;
				break;
			case 12:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 264) - 1;
				break;
			case 13:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 269) - 1;
				break;
			case 14:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 125) - 1;
				break;
			case 15:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 291) - 1;
				break;
			case 16:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 156) - 1;
				break;
			case 17:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 2085) - 1;
				break;
			case 18:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 187) - 1;
				break;
			}

			sredniBlad /= j;
		}
		plik << sredniBlad << "		" << srednia << "		" << tempMax << "		" << tempMin << "		" << rate << "  " << fileName << std::endl;
		srednia = 0;
	}
	tempMax = 5000;
	tempMin = 0.99;
	rate = 0.000005;
	for (int i = 10; i < 19; i++)
	{
		fileName = "data" + std::to_string(i) + ".txt";
		for (int j = 2; j < 102; j++)
		{
			path = INT_MAX;
			annealing.setFileName(fileName);
			annealing.loadFromFile();
			std::vector<int> permutation(annealing.getVectorLength());
			std::vector<int> bestPermutation(annealing.getVectorLength());
			length = annealing.getVectorLength();
			for (int i = 0; i < annealing.getVectorLength(); i++)
			{
				permutation[i] = i;
			}
			czas.czasStart();
			bestPermutation = annealing.findRoute(permutation, tempMax, tempMin, rate);
			czas.czasStop();
			srednia *= (j - 1);
			srednia += czas.czasWykonania();
			srednia /= j;
			sredniBlad *= (j - 1);
			switch (i)
			{
			case 10:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 212) - 1;
				break;
			case 11:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 202) - 1;
				break;
			case 12:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 264) - 1;
				break;
			case 13:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 269) - 1;
				break;
			case 14:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 125) - 1;
				break;
			case 15:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 291) - 1;
				break;
			case 16:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 156) - 1;
				break;
			case 17:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 2085) - 1;
				break;
			case 18:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 187) - 1;
				break;
			}

			sredniBlad /= j;
		}
		plik << sredniBlad << "		" << srednia << "		" << tempMax << "		" << tempMin << "		" << rate << "  " << fileName << std::endl;
		srednia = 0;
	}
	tempMax = 5000;
	tempMin = 0.99;
	rate = 0.000001;
	for (int i = 10; i < 19; i++)
	{
		fileName = "data" + std::to_string(i) + ".txt";
		for (int j = 2; j < 102; j++)
		{
			path = INT_MAX;
			annealing.setFileName(fileName);
			annealing.loadFromFile();
			std::vector<int> permutation(annealing.getVectorLength());
			std::vector<int> bestPermutation(annealing.getVectorLength());
			length = annealing.getVectorLength();
			for (int i = 0; i < annealing.getVectorLength(); i++)
			{
				permutation[i] = i;
			}
			czas.czasStart();
			bestPermutation = annealing.findRoute(permutation, tempMax, tempMin, rate);
			czas.czasStop();
			srednia *= (j - 1);
			srednia += czas.czasWykonania();
			srednia /= j;
			sredniBlad *= (j - 1);
			switch (i)
			{
			case 10:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 212) - 1;
				break;
			case 11:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 202) - 1;
				break;
			case 12:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 264) - 1;
				break;
			case 13:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 269) - 1;
				break;
			case 14:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 125) - 1;
				break;
			case 15:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 291) - 1;
				break;
			case 16:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 156) - 1;
				break;
			case 17:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 2085) - 1;
				break;
			case 18:
				sredniBlad += ((float)annealing.countLength(bestPermutation) / 187) - 1;
				break;
			}

			sredniBlad /= j;
		}
		plik << sredniBlad << "		" << srednia << "		" << tempMax << "		" << tempMin << "		" << rate << "  " << fileName << std::endl;
		srednia = 0;
	}
	*/
	/*
	while (true)
	{
		std::cout << "1. Brute force\n";
		std::cout << "2. Dynamic\n";
		std::cout << "3. Wyjscie\n";
		std::cin >> option;
		if (option == 1)
		{
			std::cout << "podaj nazwe pliku" << std::endl;
			std::cin >> fileName;
			preparations.setFileName(fileName);
			path=INT_MAX;
			preparations.loadFromFile();
			preparations.showVector();
			std::vector<int> bestPermutation(preparations.getVectorLength());
			
			std::vector<int> permutation(preparations.getVectorLength());
			for (int i = 0; i < preparations.getVectorLength(); i++)
			{
				permutation[i] = i;
			}
			length = preparations.getVectorLength();
			czas.czasStart();
			preparations.bruteForce(permutation, path, bestPermutation);
			czas.czasStop();
			std::cout << "wartosc funkcji celu dla permutacji: " << std::endl;

			for (int i = 0; i < length; i++)
			{
				std::cout << permutation[i] << "\t";
			}
			std::cout << std::endl << "jest rowna: " << std::endl;
			std::cout << path << std::endl;
			std::cout << "wykonano w czasie:\n";
			std::cout << czas.czasWykonania() << std::endl;
		}
		else if (option == 2)
		{
			std::cout << "podaj nazwe pliku" << std::endl;
			std::cin >> fileName;
			dynamic.setFileName(fileName);
			path=INT_MAX;
			dynamic.loadFromFile();
			std::vector<int> bestPermutationd(dynamic.getVectorLength());
			path = INT_MAX;
			length = dynamic.getVectorLength();
			czas.czasStart();
			dynamic.countWay(path);
			czas.czasStop();
			bestPermutationd = dynamic.getBestRoute();
			for (int i = 0; i < length; i++)
			{
				std::cout << bestPermutationd[i] << "\t";
			}
			std::cout << "\n dla drogi: ";
			std::cout << path << "\n";
			std::cout << "wykonano w czasie:\n";
			std::cout << czas.czasWykonania() << std::endl;
			break;
		}
		else if (option == 3)
		{
			exit(0);
		}
		else
		{
			std::cout << "zla komenda\n";
		}
	
	}
	
	/*std::fstream plik;
	plik.open("wyniki.txt",std::ios::out);
	float srednia=0;
	for (int i = 10; i < 19; i++)
	{
		std::string fileName;
		fileName = "data" + std::to_string(i) + ".txt";
		for (int j = 2; j < 102; j++)
		{
			path = INT_MAX;
			dynamic.setFileName(fileName);
			dynamic.loadFromFile();
			std::vector<int> bestPermutationd(dynamic.getVectorLength());
			length = dynamic.getVectorLength();
			czas.czasStart();
			dynamic.countWay(path);
			czas.czasStop();
			srednia *= (j - 1);
			srednia += czas.czasWykonania();
			srednia /= j;
		}
		plik << srednia << "  " << fileName << std::endl;
		srednia = 0;
	}
	std::string fileName;
	fileName = "data" + std::to_string(21) + ".txt";
	for (int j = 2; j < 102; j++)
	{
		path = INT_MAX;
		dynamic.setFileName(fileName);
		dynamic.loadFromFile();
		std::vector<int> bestPermutationd(dynamic.getVectorLength());
		length = dynamic.getVectorLength();
		czas.czasStart();
		dynamic.countWay(path);
		czas.czasStop();
		srednia *= (j - 1);
		srednia += czas.czasWykonania();
		srednia /= j;
	}
	plik << srednia << "  " << fileName << std::endl;
	srednia = 0;
	fileName = "data" + std::to_string(24) + ".txt";
	for (int j = 2; j < 102; j++)
	{
		path = INT_MAX;
		dynamic.setFileName(fileName);
		dynamic.loadFromFile();
		std::vector<int> bestPermutationd(dynamic.getVectorLength());
		length = dynamic.getVectorLength();
		czas.czasStart();
		dynamic.countWay(path);
		czas.czasStop();
		srednia *= (j - 1);
		srednia += czas.czasWykonania();
		srednia /= j;
	}
	plik << srednia << "  " << fileName << std::endl;
	srednia = 0;
	for (int i = 10; i < 15; i++)
	{
		std::string fileName;
		fileName = "data" + std::to_string(i) + ".txt";
		for (int j = 2; j < 102; j++)
		{
			path = INT_MAX;
			preparations.setFileName(fileName);
			preparations.loadFromFile();
			std::vector<int> bestPermutation(preparations.getVectorLength());
			std::vector<int> permutation(preparations.getVectorLength());
			for (int i = 0; i < preparations.getVectorLength(); i++)
			{
				permutation[i] = i;
			}
			length = preparations.getVectorLength();
			czas.czasStart();
			preparations.bruteForce(permutation, path, bestPermutation);
			czas.czasStop();
			srednia *= (j - 1);
			srednia += czas.czasWykonania();
			srednia /= j;
		}
		plik << srednia << "  " << fileName << std::endl;
		srednia = 0;
	}*/
	return 0;
}
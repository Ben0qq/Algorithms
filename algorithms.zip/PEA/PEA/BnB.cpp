#include "pch.h"
#include "BnB.h"


BnB::BnB()
{
}


BnB::~BnB()
{
}

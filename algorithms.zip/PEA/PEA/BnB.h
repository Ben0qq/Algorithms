#pragma once

struct Node
{
	int level;

	
};

class BnB
{
public:
	BnB();
	~BnB();
};


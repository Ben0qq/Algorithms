#include "pch.h"
#include "Annealing.h"


Annealing::Annealing()
{
	temperature = 999;
	stopTemperature = 0.99;
	coolRate = 0.00001;
}


Annealing::~Annealing()
{
}

int Annealing::getVectorLength()
{
	return this->vectorLength;
}

void Annealing::setFileName(std::string fileName)
{
	this->fileName = fileName;
}

bool Annealing::loadFromFile()
{
	int value;
	std::ifstream inFile;
	inFile.open(fileName, std::ios::in);
	if (inFile.is_open() == false)
		return false;
	inFile >> fileName;
	inFile >> vectorLength;
	this->vectorLength = vectorLength;
	values = std::vector<std::vector<int>>(vectorLength, std::vector<int>(vectorLength, 0));
	for (int i = 0; i < vectorLength; i++)
	{
		for (int j = 0; j < vectorLength; j++)
		{
			inFile >> value;
			values[i][j] = value;
		}
	}
	return true;
}

int Annealing::countLength(std::vector<int> permutation)
{
	pathValue = 0;
	for (int i = 0; i < vectorLength - 1; i++)
	{
		pathValue += values[permutation[i]][permutation[i + 1]];
	}
	pathValue += values[permutation[vectorLength - 1]][permutation[0]];

	return pathValue;
}

std::vector<int> Annealing::getNearbyRoute(std::vector<int> route)
{
	int x1 = 0, x2 = 0;
	x1 = rand() % vectorLength;
	x2 = rand() % vectorLength;
	while (x1 == x2)
	{
		x1 = rand() % vectorLength;
		x2 = rand() % vectorLength;
	}
	int temp;
	temp = route[x1];
	route[x1] = route[x2];
	route[x2] = temp;
	return route;
}

std::vector<int> Annealing::findRoute(std::vector<int> route,float tempStart , float tempStop , float rate )
{
	temperature = tempStart;
	stopTemperature = tempStop;
	coolRate = rate;
	std::random_shuffle(route.begin(), route.end());
	std::vector<int> bestRoute = route;
	std::vector<int> nearbyRoute;
	while (temperature > stopTemperature)
	{
		nearbyRoute = getNearbyRoute(route);
		if (countLength(route) < countLength(bestRoute))
			bestRoute = route;
		if (acceptRoute(countLength(route), countLength(nearbyRoute)))
			route = nearbyRoute;
		temperature *= 1 - coolRate;
	}
	return bestRoute;
}

bool Annealing::acceptRoute(int current, int adjacent)
{
	bool accept = false;
	bool shorter;
	double probability = 1;
	if (adjacent >= current)
	{
		probability = exp(-(adjacent - current) / temperature);
		shorter = false;
	}
	double random = (double)rand() / RAND_MAX;
	if (probability >= random) accept = true;
	return accept;
}



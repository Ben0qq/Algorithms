#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <algorithm>
class Annealing
{
private:
	int vectorLength;
	int pathValue = 0;
	std::string fileName;
	std::vector <std::vector<int>> values;
	double temperature=99999;
	double stopTemperature=0.99;
	double coolRate=0.01;
public:
	Annealing();
	~Annealing();
	int getVectorLength();
	void setFileName(std::string fileName);
	bool loadFromFile();
	int countLength(std::vector<int> permutation);
	std::vector<int> getNearbyRoute(std::vector<int> route);
	std::vector<int> findRoute(std::vector<int> route, float tempStart = 999, float tempStop = 0.99, float rate = 0.0001);
	bool acceptRoute(int current, int adjacent);
};


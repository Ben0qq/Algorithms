#include "pch.h"
#include "Preparations.h"


Preparations::Preparations()
{
	
}


Preparations::~Preparations()
{
}

int Preparations::getVectorLength()
{
	return this->vectorLength;
}

void Preparations::setFileName(std::string fileName)
{
	this->fileName = fileName;
}



bool Preparations::loadFromFile()
{
	int value;
	std::ifstream inFile;
	inFile.open(fileName, std::ios::in);
	if (inFile.is_open() == false)
		return false;
	inFile >> fileName;
	inFile >> vectorLength;
	maxLength = vectorLength;
	values = std::vector<std::vector<int>>(vectorLength, std::vector<int>(vectorLength, 0));
	for (int i = 0; i < vectorLength; i++)
	{
		for (int j = 0; j < vectorLength; j++)
		{
			inFile >> value;
			values[i][j] = value;
		}
	}
		return true;
}

void Preparations::showVector()
{
	for (int i = 0; i < vectorLength; i++)
	{
		for (int j = 0; j < vectorLength; j++)
		{
			printf("%4d ", values[i][j]);
		}
		std::cout << std::endl;
	}
}

int Preparations::countLength(std::vector<int> permutation)
{
	pathValue = 0;
	for (int i = 0; i < maxLength-1; i++)
	{
			pathValue += values[permutation[i]][permutation[i + 1]];
	}
	pathValue += values[permutation[maxLength-1]][permutation[0]];

	return pathValue;
}

void Preparations::swap(std::vector<int> & tab, int place1, int place2)
{
	int box;
	box = tab[place1];
	tab[place1] = tab[place2];
	tab[place2] = box;
}

void Preparations::bruteForce(std::vector<int> & permutation, int & path, std::vector<int> & bestPermutation)
{
	vectorLength--;
	if (vectorLength == 1)
	{
		if (countLength(permutation) < path)
		{
			path = countLength(permutation);
			bestPermutation = permutation;
		}
	}
	else
	{
		bruteForce(permutation, path, bestPermutation);
		bool parity;
		if (vectorLength % 2 == 1)
			parity = false;
		else
			parity = true;
		for (int i = 0; i < vectorLength - 1; i++)
		{
			if (parity == true)
				swap(permutation, i, vectorLength - 1);
			else
				swap(permutation, 0, vectorLength - 1);
			bruteForce(permutation, path, bestPermutation);
		}
	}
	vectorLength++;
}
#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdio.h>
class Preparations
{
private:
	int vectorLength;
	int maxLength;
	int pathValue=0;
	std::string fileName;
	std::vector <std::vector<int>> values;
public:
	Preparations();
	~Preparations();
	int getVectorLength();
	void setFileName(std::string fileName);
	bool loadFromFile();
	void showVector();
	int countLength(std::vector<int> permutation);
	void swap(std::vector<int> & tab, int place1, int place2);
	void bruteForce(std::vector<int> & permutation, int & path, std::vector<int> & bestPermutation);
};


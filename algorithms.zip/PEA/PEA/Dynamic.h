#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdio.h>
class Dynamic
{
	int vectorLength;
	int pathValue = 0;
	std::string fileName;
	std::vector <std::vector<int>> values;
	std::vector <std::vector<int>> paths;
	int last;
public:
	Dynamic();
	~Dynamic();
	int getVectorLength();
	void setFileName(std::string fileName);
	bool loadFromFile();
	void countWay(int & minLength);
	int Power2(int number);
	int nextBinaryPermutation(int x);
	std::vector<int> getBestRoute();
};


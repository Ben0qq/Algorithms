#include "pch.h"
#include "Dynamic.h"


Dynamic::Dynamic()
{
}


Dynamic::~Dynamic()
{
}

int Dynamic::getVectorLength()
{
	return this->vectorLength;
}

void Dynamic::setFileName(std::string fileName)
{
	this->fileName = fileName;
}

bool Dynamic::loadFromFile()
{
	int value;
	std::ifstream inFile;
	inFile.open(fileName, std::ios::in);
	if (inFile.is_open() == false)
		return false;
	inFile >> fileName;
	inFile >> vectorLength;
	values = std::vector<std::vector<int>>(vectorLength, std::vector<int>(vectorLength, 0));
	paths = std::vector<std::vector<int>>(vectorLength-1, std::vector<int>(Power2(vectorLength-1), 0));
	for (int i = 0; i < vectorLength; i++)
	{
		for (int j = 0; j < vectorLength; j++)
		{
			inFile >> value;
			values[i][j] = value;
		}
	}
	return true;
}

void Dynamic::countWay(int & minLength)
{
	std::vector<std::vector<int>> pathsTemp = std::vector<std::vector<int>>(vectorLength-1, std::vector<int>(Power2(vectorLength-1), 0));
	for (int i = 0; i < vectorLength-1; ++i)
	{
		pathsTemp[i][0] = values[vectorLength-1][i];
	}
	for (int k = 1; k < vectorLength - 1; k++)
	{
		int permutation = Power2(k) - 1;
			while (permutation < Power2(vectorLength - 1))
			{
				for (int i = 0; i < vectorLength-1; ++i)
				{
					if ((Power2(i) & permutation)==0)
					{
						int saveIndex;
						int min = INT_MAX;
						for (int index = 0; index < vectorLength-1; ++index)
						{
							if (Power2(index) & permutation)
							{
								int tempPermutation = permutation & (~(1 << index));
								
								if ((values[index][i] + pathsTemp[index][tempPermutation]) < min)
								{
									min = values[index][i] + pathsTemp[index][tempPermutation];
									saveIndex = index;
								}
							}
						}
						
						pathsTemp[i][permutation] = min;
						
						paths[i][permutation] = saveIndex;
					}
				}
				permutation = nextBinaryPermutation(permutation);
			}
	}
	int saveIndex;
	int min = INT_MAX;
	int permutation = Power2(vectorLength-1) - 1;
	for (int index = 0; index < vectorLength - 1; ++index)
	{
		if ((Power2(index) & permutation))
		{
			int tempPermutation = permutation & (~(1 << index));
			if ((values[index][vectorLength - 1] + pathsTemp[index][tempPermutation]) < min)
			{
				min = values[index][vectorLength - 1] + pathsTemp[index][tempPermutation];
				saveIndex = index;
			}
		}
	}
	last = saveIndex;
	minLength = min;
}

int Dynamic::Power2(int number)
{
	return 1 << number;
}

int Dynamic::nextBinaryPermutation(int x)
{
	unsigned int t = (x | (x - 1)) + 1;
	unsigned int y = t | ((((t & 0 - t) / (x & 0 - x)) >> 1) - 1);
	return y;
}

std::vector<int> Dynamic::getBestRoute()
{
	std::vector<int> bestRoute (vectorLength);
	int permutation = Power2(vectorLength-1) - 1;
	bestRoute[0] = vectorLength-1;
	for (int i = 1; i < vectorLength; ++i)
	{
		bestRoute[i] = last;
		permutation = permutation & (~(1 << last));
		last = paths[last][permutation];
	}
	return bestRoute;
}


	

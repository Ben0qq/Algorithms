﻿#ifndef PCH_H
#define PCH_H

// TODO: w tym miejscu dodaj nagłówki, które mają być wstępnie kompilowane

#endif //PCH_H

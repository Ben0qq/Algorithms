#include "pch.h"
#include "Genetic.h"


Genetic::Genetic()
{
}


Genetic::~Genetic()
{
}

int Genetic::getVectorLength()
{
	return this->vectorLength;
}

void Genetic::setFileName(std::string fileName)
{
	this->fileName = fileName;
}

void Genetic::swap(std::vector<int> & tab, int place1, int place2)
{
	int box;
	box = tab[place1];
	tab[place1] = tab[place2];
	tab[place2] = box;
}

bool Genetic::loadFromFile()
{
	int value;
	std::ifstream inFile;
	inFile.open(fileName, std::ios::in);
	if (inFile.is_open() == false)
		return false;
	inFile >> fileName;
	inFile >> vectorLength;
	this->vectorLength = vectorLength;
	values = std::vector<std::vector<int>>(vectorLength, std::vector<int>(vectorLength, 0));
	for (int i = 0; i < vectorLength; i++)
	{
		for (int j = 0; j < vectorLength; j++)
		{
			inFile >> value;
			values[i][j] = value;
		}
	}
	return true;
}

int Genetic::countLength(std::vector<int> permutation)
{
	pathValue = 0;
	for (int i = 0; i < vectorLength - 1; i++)
	{
		pathValue += values[permutation[i]][permutation[i + 1]];
	}
	pathValue += values[permutation[vectorLength - 1]][permutation[0]];

	return pathValue;
}

void Genetic::createRoutes()
{
	for (int i = 0; i < populationSize; i++)
	{
		routes[i] = permutation;
		std::random_shuffle(routes[i][0], routes[i][vectorLength - 1]);
	}
}

double Genetic::getFitness(std::vector<int> route)
{
	fitness = (1.0 / (double)countLength(route)) * 10000.0;
}

void Genetic::sortRoutes()
{
	std::sort(routes[0], routes[populationSize - 1], getFitness);
}

void Genetic::crossover(std::vector<int> & route1, std::vector<int> & route2)
{
	int separator = vectorLength / 3;
	std::vector<int> temp1(vectorLength);
	std::vector<int> temp2(vectorLength);
	for (int i = separator; i < separator * 2; i++)
	{
		temp1[i] = route1[i];
		temp2[i] = route2[i];
		route2[i] = temp1[i];
		route1[i] = temp2[i];
	}
}

std::vector<int> Genetic::mutate()
{
	for (int i = 0; i < populationSize; i++)
	{
		double random = (double)rand() / RAND_MAX;
		if (random < mutationRate)
		{
			int x1 = 0, x2 = 0;
			x1 = rand() % vectorLength;
			x2 = rand() % vectorLength;
			while (x1 == x2)
			{
				x1 = rand() % vectorLength;
				x2 = rand() % vectorLength;
			}
			swap(routes[i], x1, x2);
		}
	}
}

std::vector<std::vector<int>> Genetic::tournament(std::vector<int> route)
{
	sortRoutes();
	std::vector<std::vector<int>> tournamentPopulation(tournamentSize);
	for (int i = 0; i < tournamentSize; i++)
	{
		tournamentPopulation[i] = routes[i];
	}
	return tournamentPopulation;
}

void Genetic::start()
{
	createRoutes();
	for (int i = 0; i < generations; i++)
	{

	}
}


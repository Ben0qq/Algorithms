#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <algorithm>
#include <random>
class Genetic
{
private:
	int vectorLength;
	int pathValue = 0;
	std::string fileName;
	std::vector <std::vector<int>> values;
	double fitness;
	std::vector<int> permutation;
	std::vector <std::vector<int>> routes;
	double mutationRate = 0.25;
	int tournamentSize = 3;
	int eliteRoutes = 1;
	int generations = 30;
	int populationSize=8;
public:
	Genetic();
	~Genetic();
	int getVectorLength();
	void setFileName(std::string fileName);
	void swap(std::vector<int>& tab, int place1, int place2);
	bool loadFromFile();
	int countLength(std::vector<int> permutation);
	void createRoutes();
	double getFitness(std::vector<int>);
	void sortRoutes();
	void crossover(std::vector<int> &, std::vector<int> &);
	std::vector<int> mutate();
	std::vector<std::vector<int>> tournament(std::vector<int> route);
	void start();
};


